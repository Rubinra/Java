package common;

public enum Gender {
	MALE, FEMALE
	
}
