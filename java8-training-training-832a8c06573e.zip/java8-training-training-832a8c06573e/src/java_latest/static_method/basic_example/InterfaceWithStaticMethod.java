package java_latest.static_method.basic_example;

public interface InterfaceWithStaticMethod {

	void abstractMethod(); // Abstract Method

	static void staticMethod() {
		System.out.println("It is a static method");
	}
}
