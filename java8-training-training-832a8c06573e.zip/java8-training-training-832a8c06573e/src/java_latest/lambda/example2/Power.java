package java_latest.lambda.example2;
@FunctionalInterface   //@FunctionalInterface annotation is optional  but highly recommended
public interface Power {
	int calculate(int number);
}
