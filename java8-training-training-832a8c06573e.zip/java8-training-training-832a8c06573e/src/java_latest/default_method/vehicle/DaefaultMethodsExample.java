package java_latest.default_method.vehicle;


public class DaefaultMethodsExample {
	
	public static void main(String[] args) {
		
		Vehicle vehicle=new Car();
		System.out.println(vehicle.getSpeedInMilesPerHour());
	}
}