package java_latest.default_method.vehicle;


class Car implements Vehicle
{
	public double getSpeed()
	{
		return 100;
	}
}

